<?php

namespace App\Livewire\Admin\Graficos;

use Livewire\Component;

class Grafico3 extends Component
{
    public function render()
    {
        return view('livewire.admin.graficos.grafico3');
    }
}
