<?php

namespace App\Livewire\Citas;

use Livewire\Component;

class Views extends Component
{
    public function render()
    {
        return view('livewire.citas.views');
    }
}
