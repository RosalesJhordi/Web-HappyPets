<?php

namespace App\Livewire\Productos;

use Livewire\Component;

class Products extends Component
{
    public function render()
    {
        return view('livewire.productos.products');
    }
}
