@extends('Layout.App')

@section('titulo')
    Productos
@endsection

@section('contenido')
    @livewire('productos.productos')
@endsection
