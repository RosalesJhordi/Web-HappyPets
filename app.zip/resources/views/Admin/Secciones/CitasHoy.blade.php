@extends('Admin.Inicio')

@section('contenido')
    @livewire('admin.citas.inicio')
@endsection
