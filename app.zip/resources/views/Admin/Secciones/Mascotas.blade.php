@extends('Admin.Inicio')

@section('contenido')
    @livewire('admin.mascotas.inicio')
@endsection
