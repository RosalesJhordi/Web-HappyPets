@extends('Admin.Inicio')

@section('contenido')
    @livewire('admin.libro.libros')
@endsection
