@extends('Layout.App')

@section('titulo')
    Servicios
@endsection

@section('contenido')
    @livewire('servicios.inicio')
@endsection
