<?php $__env->startSection('titulo'); ?>
    Servicios
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('servicios.inicio');

$__html = app('livewire')->mount($__name, $__params, 'lw-2355610296-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.App', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RosalesJhon\Desktop\Web-HappyPets\resources\views/Servicios.blade.php ENDPATH**/ ?>