<div class="max-w-4xl p-4 mx-auto">
    <div class="flex items-center justify-between mb-4">
        <h2 class="text-lg font-semibold">
            <?php echo e(now()->day); ?> <?php echo e(ucfirst(now()->locale('es')->monthName)); ?> del <?php echo e(now()->year); ?>

        </h2>
        <button class="px-4 py-2 text-white bg-blue-500 rounded-md">
            Agregar evento
        </button>
    </div>

    <div class="grid grid-cols-7 text-center text-gray-600">
        <div>Lun</div>
        <div>Mar</div>
        <div>Mié</div>
        <div>Jue</div>
        <div>Vie</div>
        <div>Sáb</div>
        <div>Dom</div>
    </div>

    <div class="grid grid-cols-7 gap-2 mt-2">
        <!-- Agregar días vacíos al inicio -->
        <!--[if BLOCK]><![endif]--><?php for($i = 0; $i < $primerDiaDelMes; $i++): ?>
            <div></div>
        <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->

        <!-- Días del mes -->
        <!--[if BLOCK]><![endif]--><?php for($dia = 1; $dia <= $diasDelMes; $dia++): ?>
            <div class="relative p-2 border rounded-lg
                <?php echo e($dia == $diaActual ? 'bg-blue-500 text-white' : 'text-gray-700'); ?>">
                <span><?php echo e($dia); ?></span>

                <!-- Mostrar eventos -->
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!--[if BLOCK]><![endif]--><?php if(Carbon\Carbon::parse($evento['fecha'])->day == $dia): ?>
                        <div class="mt-2 text-sm <?php echo e($dia == $diaActual ? 'text-white' : 'text-blue-500'); ?>">
                            <?php echo e($evento['titulo']); ?> - <?php echo e($evento['hora']); ?>

                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div>
<?php /**PATH C:\Users\RosalesJhon\Desktop\Web-HappyPets\resources\views/livewire/admin/citas/mes.blade.php ENDPATH**/ ?>