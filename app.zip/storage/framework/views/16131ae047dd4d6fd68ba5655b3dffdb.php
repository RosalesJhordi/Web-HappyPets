<?php $__env->startSection('titulo'); ?>
    Inicio
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.secciones.slide');

$__html = app('livewire')->mount($__name, $__params, 'lw-1146410428-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <div class="w-full">

        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('productos.todos');

$__html = app('livewire')->mount($__name, $__params, 'lw-1146410428-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('servicios.todas');

$__html = app('livewire')->mount($__name, $__params, 'lw-1146410428-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        
        
        <div class="visme_d" style="height: 50vh;" data-title="Contact Form" data-url="8r6nwpjm-contact-form"
            data-domain="forms" data-full-page="false" data-min-height="1000px" data-form-id="40366"></div>
        <script src="https://static-bundles.visme.co/forms/vismeforms-embed.js"></script>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.App', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RosalesJhon\Desktop\Web-HappyPets\resources\views/welcome.blade.php ENDPATH**/ ?>