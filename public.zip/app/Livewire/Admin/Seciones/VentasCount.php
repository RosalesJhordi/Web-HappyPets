<?php

namespace App\Livewire\Admin\Seciones;

use Livewire\Component;

class VentasCount extends Component
{
    public function render()
    {
        return view('livewire.admin.seciones.ventas-count');
    }
}
