<div class="w-full">
    <div class="grid w-full grid-cols-2 gap-2 py-5 md:gap-5 md:flex md:flex-wrap md:grid-cols-4">
        <!--[if BLOCK]><![endif]--><?php if(Session::get('authToken')): ?>
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.secciones.usuarios-count');

$__html = app('livewire')->mount($__name, $__params, 'lw-1853385080-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.secciones.ganancias');

$__html = app('livewire')->mount($__name, $__params, 'lw-1853385080-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.secciones.productos-count');

$__html = app('livewire')->mount($__name, $__params, 'lw-1853385080-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.secciones.mascotas-count');

$__html = app('livewire')->mount($__name, $__params, 'lw-1853385080-3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.secciones.servicios-count');

$__html = app('livewire')->mount($__name, $__params, 'lw-1853385080-4', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.secciones.categorias-count');

$__html = app('livewire')->mount($__name, $__params, 'lw-1853385080-5', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    </div>
    <h1 class="text-xl font-semibold text-gray-400">Graficos</h1>
    <div class="grid flex-wrap w-full grid-cols-1 gap-5 py-5 md:grid-cols-2">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.graficos.grafico1');

$__html = app('livewire')->mount($__name, $__params, 'lw-1853385080-6', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.graficos.grafico2');

$__html = app('livewire')->mount($__name, $__params, 'lw-1853385080-7', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.graficos.grafico3');

$__html = app('livewire')->mount($__name, $__params, 'lw-1853385080-8', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.graficos.grafico4');

$__html = app('livewire')->mount($__name, $__params, 'lw-1853385080-9', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
    <div class="grid items-center justify-center w-full gap-5 md:flex">
        <div class="tableii">
            <div class="w-full h-full overflow-x-auto bg-white border border-gray-200 rounded-lg shadow-sm">
                <div class="py-2 text-center text-gray-600">
                    <h1 class="text-lg font-semibold">Tabla Usuarios</h1>
                </div>
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase">#</th>
                            <th class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase">Nombres</th>
                            <th class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase">Apellidos</th>
                            <th class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase">Teléfono</th>
                            <th class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase">Fecha Creación</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $datosClientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clientes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th class="px-6 py-4 whitespace-nowrap"><?php echo e($loop->iteration); ?></th>
                                <td class="px-6 py-4 whitespace-nowrap"><?php echo e($clientes['nombres']); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap"><?php echo e($clientes['apellidos']); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap"><?php echo e($clientes['telefono']); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap"><?php echo e(\Carbon\Carbon::parse($clientes['created_at'])->diffForHumans()); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>
            </div>
        </div>

        <div class="tableii2">
            <div class="w-full h-full overflow-x-auto bg-white border border-gray-200 rounded-lg shadow-sm">
                <div class="py-2 text-center text-gray-600">
                    <h1 class="text-lg font-semibold">Tabla Empleados</h1>
                </div>
                <table class="min-w-full divide-y divide-gray-200 table-auto">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase">#</th>
                            <th class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase">Nombres</th>
                            <th class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase">DNI</th>
                            <th class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase">Permisos</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $datosEmpleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th class="px-6 py-4 whitespace-nowrap"><?php echo e($loop->iteration); ?></th>
                                <td class="px-6 py-4 whitespace-nowrap"><?php echo e($empleado['nombres']); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap"><?php echo e($empleado['dni']); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <ul class="flex flex-wrap gap-2">
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $empleado['permisos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permiso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="px-2 py-1 text-xs font-medium text-white bg-blue-500 rounded-full"><?php echo e($permiso); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </ul>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<?php /**PATH C:\Users\RosalesJhon\Desktop\Web-HappyPets\resources\views/livewire/admin/views/inicio.blade.php ENDPATH**/ ?>