<?php $__env->startSection('titulo'); ?>
    Productos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <div class="flex items-center justify-center w-full">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('filtro.producto');

$__html = app('livewire')->mount($__name, $__params, 'lw-1986577392-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.App', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RosalesJhon\Desktop\Web-HappyPets\resources\views/Productos.blade.php ENDPATH**/ ?>