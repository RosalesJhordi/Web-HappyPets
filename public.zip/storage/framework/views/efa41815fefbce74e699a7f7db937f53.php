<div class="w-auto drawer drawer-end">
    <input id="my-drawer-4" type="checkbox" class="drawer-toggle" />
    <div class="drawer-content">
        <!-- Page content here -->
        <label for="my-drawer-4" class="cursor-pointer drawer-button">
            <div id="openDrawer"
                class="flex items-center justify-center text-gray-400 rounded-full indicator hover:white">
                <div class="flex items-center mr-3">
                    <div class="text-2xl indicator">
                        <span class="text-xs indicator-item badge badge-primary">
                            <!--[if BLOCK]><![endif]--><?php if($datosCarrito): ?>
                                <?php echo e(count($NotiPedido + $NotiCita + $NotiNovedad)); ?>

                            <?php else: ?>
                                0
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </span>
                        <i class="fa-regular fa-bell"></i>
                    </div>
                </div>
            </div>
        </label>
    </div>
    <div class="drawer-side" style="z-index: 9999;">
        <label for="my-drawer-4" aria-label="close sidebar" class="drawer-overlay"></label>
        <ul class="min-h-full p-4 bg-white w-80 md:w-96 menu text-base-content" style="z-index: 9999;">

            <div class="container mx-auto">
                <h1 class="mb-8 text-3xl font-bold text-center text-gray-900">Notificaciones</h1>
                <!--[if BLOCK]><![endif]--><?php if(Session::has('authToken')): ?>
                    <div class="tabs">
                        <div class="block" wire:ignore.self>
                            <ul
                                class="grid items-center justify-center min-w-full grid-cols-3 gap-2 transition-all duration-300 border-b border-gray-200">
                                
                                <!--[if BLOCK]><![endif]--><?php if(in_array('Administrador', $this->permisos) || in_array('Cajero/Vendedor', $this->permisos)): ?>
                                    <li class="w-full text-center">
                                        <a href="javascript:void(0)"
                                            class="flex  items-center justify-center px-1 py-1 font-medium text-center text-gray-500 border-b-2 border-transparent rounded-md hover:text-gray-800 active active:bg-[#8492a6] tablink whitespace-nowrap"
                                            data-tab="tabs-with-underline-1" role="tab">Pedidos
                                            <span class="w-5 h-5 text-white bg-purple-600 rounded-full">
                                                <?php echo e(count($NotiPedido)); ?>

                                            </span>
                                        </a>
                                    </li>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                
                                <?php if(in_array('Administrador', $this->permisos) || in_array('Veterinario', $this->permisos)): ?>
                                    <li class="w-full text-center">
                                        <a href="javascript:void(0)"
                                            class="flex items-center justify-center px-1 py-1 font-medium text-center text-gray-500 border-b-2 border-transparent rounded-md hover:text-gray-800 active:bg-[#8492a6] tablink whitespace-nowrap"
                                            data-tab="tabs-with-underline-2" role="tab">Citas
                                            <span class="w-5 h-5 text-white bg-purple-600 rounded-full">
                                                <?php echo e(count($NotiCita)); ?>

                                            </span>
                                        </a>
                                    </li>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                
                                <?php if(in_array('Administrador', $this->permisos) ||
                                        !empty(array_intersect(['Cliente', 'Veterinario', 'Cajero/Vendedor'], $this->permisos))): ?>
                                    <li class="w-full text-center">
                                        <a href="javascript:void(0)"
                                            class="flex items-center justify-center px-1 py-1 font-medium text-center text-gray-500 border-b-2 border-transparent rounded-md hover:text-gray-800 active:bg-[#8492a6] tablink whitespace-nowrap"
                                            data-tab="tabs-with-underline-3" role="tab">Novedades
                                            <span class="w-5 h-5 text-white bg-purple-600 rounded-full">
                                                <?php echo e(count($NotiNovedad)); ?>

                                            </span>
                                        </a>
                                    </li>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </ul>

                        </div>
                        <div class="mt-5">
                            <!--[if BLOCK]><![endif]--><?php if(in_array('Administrador', $this->permisos) || in_array('Cajero/Vendedor', $this->permisos)): ?>
                                <div id="tabs-with-underline-1" role="tabpanel"
                                    aria-labelledby="tabs-with-underline-item-1" class="tabcontent">
                                    <div class="space-y-6">
                                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $NotiPedido; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <div class="bg-white border border-gray-200 rounded-lg shadow-md">
                                                <div class="p-4 md:flex md:items-center">
                                                    <div class="flex-1 space-y-1">
                                                        <p class="text-gray-700 text-md"><?php echo e($noti['data']['mensaje']); ?>

                                                        </p>
                                                        <p class="text-sm font-semibold text-gray-900">
                                                            <?php echo e($noti['data']['codigo_operacion']); ?></p>
                                                            <span><?php echo e(\Carbon\Carbon::parse($noti['created_at'])->diffForHumans()); ?></span>
                                                    </div>
                                                    <div class="mt-4 md:mt-0 md:ml-4">
                                                        <button wire:click='MarcarLeidoPedidio("<?php echo e($noti['id']); ?>")'
                                                            class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md shadow-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-75">
                                                            <svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                                                viewBox="0 0 24 24" stroke-width="1.5"
                                                                stroke="currentColor" class="size-2">
                                                                <path stroke-linecap="round" stroke-linejoin="round"
                                                                    d="m4.5 12.75 6 6 9-13.5" />
                                                            </svg>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                            <p class="w-full py-4 text-center text-gray-400">No hay notificacines nuevas
                                            </p>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <h1>Leido:</h1>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $NotiPedidoAll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notii): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="bg-white border border-gray-200 rounded-lg shadow-md">
                                                <div class="p-4 md:flex md:items-center">
                                                    <div class="flex-1 space-y-1">
                                                        <p class="text-gray-700 text-md">
                                                            <?php echo e($notii['data']['mensaje']); ?></p>
                                                        <p class="text-sm font-semibold text-gray-900">
                                                            <?php echo e($notii['data']['codigo_operacion']); ?></p>
                                                            <span><?php echo e(\Carbon\Carbon::parse($notii['created_at'])->diffForHumans()); ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                                    </div>
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <?php if(in_array('Administrador', $this->permisos) || in_array('Veterinario', $this->permisos)): ?>
                                <div id="tabs-with-underline-2" role="tabpanel"
                                    aria-labelledby="tabs-with-underline-item-2" class="tabcontent">
                                    <div class="space-y-6">
                                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $NotiCita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <div class="bg-white border border-gray-200 rounded-lg shadow-md">
                                                <div class="p-4 md:flex md:items-center">
                                                    <div class="flex-1 space-y-1">
                                                        <p class="text-gray-700 text-md"><?php echo e($noti['data']['mensaje']); ?>

                                                        </p>
                                                            <span><?php echo e(\Carbon\Carbon::parse($noti['created_at'])->diffForHumans()); ?></span>
                                                    </div>
                                                    <div class="mt-4 md:mt-0 md:ml-4">
                                                        <button wire:click='MarcarLeidoCitas("<?php echo e($noti['id']); ?>")'
                                                            class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md shadow-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-75">
                                                            <svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                                                viewBox="0 0 24 24" stroke-width="1.5"
                                                                stroke="currentColor" class="size-2">
                                                                <path stroke-linecap="round" stroke-linejoin="round"
                                                                    d="m4.5 12.75 6 6 9-13.5" />
                                                            </svg>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                            <p class="w-full py-4 text-center text-gray-400">No hay notificacines
                                                nuevas
                                            </p>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <h1>Leido:</h1>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $NotiCitasAll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notii): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="bg-white border border-gray-200 rounded-lg shadow-md">
                                                <div class="p-4 md:flex md:items-center">
                                                    <div class="flex-1 space-y-1">
                                                        <p class="text-gray-700 text-md">
                                                            <?php echo e($notii['data']['mensaje']); ?></p>
                                                            <span><?php echo e(\Carbon\Carbon::parse($notii['created_at'])->diffForHumans()); ?></span>

                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                                    </div>
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <?php if(in_array('Administrador', $this->permisos) ||
                                    !empty(array_intersect(['Cliente', 'Veterinario', 'Cajero/Vendedor'], $this->permisos))): ?>
                                <div id="tabs-with-underline-3" role="tabpanel"
                                    aria-labelledby="tabs-with-underline-item-3" class="tabcontent">
                                    <div class="space-y-6">
                                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $NotiNovedad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <div class="bg-white border border-gray-200 rounded-lg shadow-md">
                                                <div class="p-4 md:flex md:items-center">
                                                    <div class="flex-1 space-y-1">
                                                        <p class="text-gray-700 text-md">
                                                            <?php echo e($noti['data']['mensaje']); ?>

                                                        </p>
                                                        <p class="text-sm font-semibold text-gray-900">
                                                            <?php echo e($noti['data']['estado']); ?></p>
                                                        <p class="text-sm font-semibold text-gray-900">
                                                            <?php echo e($noti['data']['observaciones']); ?></p>
                                                            <span><?php echo e(\Carbon\Carbon::parse($noti['created_at'])->diffForHumans()); ?></span>
                                                    </div>
                                                    <div class="mt-4 md:mt-0 md:ml-4">
                                                        <button
                                                            wire:click='MarcarLeidoNovedades("<?php echo e($noti['id']); ?>")'
                                                            class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md shadow-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-75">
                                                            <svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                                                viewBox="0 0 24 24" stroke-width="1.5"
                                                                stroke="currentColor" class="size-2">
                                                                <path stroke-linecap="round" stroke-linejoin="round"
                                                                    d="m4.5 12.75 6 6 9-13.5" />
                                                            </svg>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <p class="w-full py-4 text-center text-gray-400">No hay notificacines
                                            nuevas
                                        </p>
                                        <h1>Leido:</h1>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $NotiNovedades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notii): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="bg-white border border-gray-200 rounded-lg shadow-md">
                                                <div class="p-4 md:flex md:items-center">
                                                    <div class="flex-1 space-y-1">
                                                        <p class="text-gray-700 text-md">
                                                            <?php echo e($notii['data']['mensaje']); ?></p>
                                                        <p class="text-sm font-semibold text-gray-900">
                                                            <?php echo e($notii['data']['estado']); ?></p>
                                                        <p class="text-sm font-semibold text-gray-900">
                                                            <?php echo e($notii['data']['observaciones']); ?></p>
                                                            <span><?php echo e(\Carbon\Carbon::parse($notii['created_at'])->diffForHumans()); ?></span>

                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                                    </div>
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        </div>

                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </ul>
    </div>
</div>
<?php /**PATH C:\Users\RosalesJhon\Desktop\Web-HappyPets\resources\views/livewire/admin/notificaciones.blade.php ENDPATH**/ ?>