@extends('Admin.Inicio')

@section('contenido')
    @livewire('admin.ventas.pedidos')
@endsection
