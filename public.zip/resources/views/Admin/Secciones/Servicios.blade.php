@extends('Admin.Inicio')

@section('contenido')
    @livewire('admin.servicios.inicio')
@endsection
