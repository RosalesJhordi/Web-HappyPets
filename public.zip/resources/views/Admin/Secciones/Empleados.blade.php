@extends('Admin.Inicio')

@section('contenido')
    @livewire('admin.usuarios.empleados')
@endsection
