@extends('Admin.Inicio')

@section('contenido')
    @livewire('admin.productos.productos')
@endsection
