@extends('Layout.App')

@section('titulo')
    Perfil
@endsection

@section('contenido')
    @livewire('perfil.perfil')
@endsection
